from enum import Enum

# Define an Enum for logical operators
class LogicalOperator(Enum):
    AND = "and"
    OR = "or"
    NOT = "not"